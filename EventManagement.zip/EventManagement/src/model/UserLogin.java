package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="UserLogin/signup")
public class UserLogin {
	@Id
	@GeneratedValue( strategy=GenerationType.AUTO)
	@Column(name = "user_id")
	private String userId;
	@Column(name = "password",nullable=false)
	private String password;
	public LoginStaus getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(LoginStaus loginStatus) {
		this.loginStatus = loginStatus;
	}
	@Column(name="login_status")
	private LoginStaus loginStatus;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserLogin(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
}
