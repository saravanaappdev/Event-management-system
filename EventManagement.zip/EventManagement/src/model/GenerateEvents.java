package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="generated_events")
public class GenerateEvents {
	@Id
	@Column(name="user_id")
	private String userId;
	@Column(name="event_id",nullable=false)
	private String eventId;
	@Column(name="event_name",nullable=false)
	private String eventName;
	@Column(name="event_status_code",nullable=false)
	private StatusCode status;
	@Column(name="event_type",nullable=false)
	private EventType eventType;
	@Column(name="organizer_id",nullable=false)
	private String OrganizerId;
	@Column(name="event_start_time")
	private String eventStartTime;
	@Column(name="event_end_time")
	private String eventEndTime;
	@Column(name="no_of_participation")
	private int noOfParticipation;
	@Column(name="derivedDuration")
	private String derivedDuration;
	@Column(name="entryType",nullable=false)
	private EntryType entryType;
	@Column(name="VenueId",nullable=false)
	private String VenueId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public StatusCode getStatus() {
		return status;
	}
	public void setStatus(StatusCode status) {
		this.status = status;
	}
	public EventType getEventType() {
		return eventType;
	}
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}
	public String getOrganizerId() {
		return OrganizerId;
	}
	public void setOrganizerId(String organizerId) {
		OrganizerId = organizerId;
	}
	public String getEventStartTime() {
		return eventStartTime;
	}
	public void setEventStartTime(String eventStartTime) {
		this.eventStartTime = eventStartTime;
	}
	public String getEventEndTime() {
		return eventEndTime;
	}
	public void setEventEndTime(String eventEndTime) {
		this.eventEndTime = eventEndTime;
	}
	public int getNoOfParticipation() {
		return noOfParticipation;
	}
	public void setNoOfParticipation(int noOfParticipation) {
		this.noOfParticipation = noOfParticipation;
	}
	public String getDerivedDuration() {
		return derivedDuration;
	}
	public void setDerivedDuration(String derivedDuration) {
		this.derivedDuration = derivedDuration;
	}
	public EntryType getEntryType() {
		return entryType;
	}
	public void setEntryType(EntryType entryType) {
		this.entryType = entryType;
	}
	public String getVenueId() {
		return VenueId;
	}
	public void setVenueId(String venueId) {
		VenueId = venueId;
	}
	

	

}
