package model;

public enum LoginStaus {
	LOGGEDIN,LOGGEDOUT;
}
