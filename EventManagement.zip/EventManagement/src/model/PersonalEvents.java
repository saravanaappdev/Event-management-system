package model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="personal_events")
public class PersonalEvents {
	@Id
	 @Column(name="event_id")
	 private String userId;
     @Column(name="event_id",nullable=false)
     private String eventId;
     @Column(name="event_name",nullable=false)
     private String eventName;
     @Column(name="event_date",nullable=false)
     private Date eventDate;
     @Column(name="event_description")
     private Date eventDescription;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEventId() {
		return eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public Date getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(Date eventDescription) {
		this.eventDescription = eventDescription;
	}
     
     
	
	
}
