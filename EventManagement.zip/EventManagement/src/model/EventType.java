package model;

public enum EventType {
	COMEDY,MUSIC,MOVIE,MARRIAGE;

}
