package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="organizer_details")
public class OrganizerDetails {
	@Id
	@Column(name="user_id")
	private String userId;
	@Column(name="event_id",nullable=false)
	private String eventId;
	@Column(name="event_id",nullable=false)
	private EventType eventType;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public EventType getEventType() {
		return eventType;
	}
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}
	

}
