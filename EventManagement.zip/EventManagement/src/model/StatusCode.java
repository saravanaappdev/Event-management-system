package model;

public enum StatusCode {
     PROCESSING,CANCELLED,PAID,WAIT;
}
