package model;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_profile")
public class UserDetails {
	@Id
	@Column(name="user_id",nullable=false)
	private String userId;
	@Column(name="first_name",nullable=false)
	private Blob image;
	private String firstName;
	@Column(name="last_name",nullable=false)
	private String lastName;
	@Column(name="gender",nullable=false)
	private String Gender;
	@Column(name="date_of_birth",nullable=false)  
	private Date dateOfBirth;
 	@Column(name="marital_status",nullable=false)
	private MaritalStatus maritalStatus;
	@Column(name="email_id",nullable=false)
	private String emailId;
	@Column(name="mobile_no",nullable=false)
	private Long   mobileNo;
	@Column(name="address_id",nullable=false)
	@Embedded
	private Address address;
	
	public String getFirstName() {
		return firstName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
		public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public MaritalStatus getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(MaritalStatus maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
		

}
