package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="entry_type")
public class EntryType {
  @Id
  @Column(name="user_id")
  private String userId;
  @Column(name="event_id",nullable=false)
  private String eventId;
  @Column(name="event_type",nullable=false)
  private String entryType;
  @Column(name="entry_fee",nullable=false)
  private String entryFee;
  @Column(name="discount",nullable=false)
  private String discount;
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getEventId() {
	return eventId;
}
public void setEventId(String eventId) {
	this.eventId = eventId;
}
public String getEntryType() {
	return entryType;
}
public void setEntryType(String entryType) {
	this.entryType = entryType;
}
public String getEntryFee() {
	return entryFee;
}
public void setEntryFee(String entryFee) {
	this.entryFee = entryFee;
}
public String getDiscount() {
	return discount;
}
public void setDiscount(String discount) {
	this.discount = discount;
}
  
	
	
}
