package model;

import javax.persistence.Embeddable;

@Embeddable
public enum LoginStatus {
	LOGGEDIN,LOGGEDOUT;

}
