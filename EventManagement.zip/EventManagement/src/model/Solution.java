package model;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Solution {

public static void main(String args[]){

	SessionFactory sf=new Configuration().configure().buildSessionFactory();
	Session session1 = sf.openSession();
	session1.beginTransaction();
	UserDetails user1=new UserDetails();
	user1.setFirstName("saravana");
	user1.setLastName("kumar");
	user1.setAddress("coimbatore");
	user1.setDateOfBirth(new Date());
	user1.setEmailId("saravanakumar@gmail.com");
	user1.setGender("Male");
	user1.setUserId("1");
	user1.setMobileNo("46546456");
	session1.save(user1);
	
	session1.getTransaction().commit();
	session1.close();
	


}
}
