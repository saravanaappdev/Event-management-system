package model;

public enum MaritalStatus {

}
